@extends('layouts.app')

@section('content')
<div class="container">
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif


<div class="row g-4 mb-5">
    <div class="col-md-4">
        <div class="card border-0 shadow-lg h-100" style="background: linear-gradient(145deg, #1a1a1a 0%, #2c2c2c 100%); border-top: 4px solid #d4af37 !important;">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="mb-0 fw-bold" style="color: #d4af37; letter-spacing: 1px;">
                        <i class="fa-solid fa-crown me-2"></i>VIP ROOMS
                    </h5>
                    <span class="badge" style="background: rgba(212, 175, 55, 0.1); color: #d4af37;">Premium</span>
                </div>
                         <h5 class="fw-bold vip-total text-light">Total {{ $stats['vip']['total'] }}</h5>
                
                <div class="row g-0 rounded-3 p-3" style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05);">
                    <div class="col-4 text-center">
                        <small class="text-uppercase fw-semibold" style="color: #a0a0a0; font-size: 0.65rem;">Available</small>
                        <h3 class="fw-bold mb-0 mt-1" style="color: #2ecc71;">{{ $stats['vip']['available'] }}</h3>
                    </div>
                    <div class="col-4 text-center border-start border-white border-opacity-10 border-end">
                        <small class="text-uppercase fw-semibold" style="color: #a0a0a0; font-size: 0.65rem;">Booked</small>
                        <h3 class="fw-bold mb-0 mt-1" style="color: #e74c3c;">{{ $stats['vip']['booked'] }}</h3>
                    </div>
                    <div class="col-4 text-center">
                        <small class="text-uppercase fw-semibold" style="color: #a0a0a0; font-size: 0.65rem;">Maint.</small>
                        <h3 class="fw-bold mb-0 mt-1" style="color: #f1c40f;">{{ $stats['vip']['maintenance'] }}</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
       <div class="col-md-4">
        <div class="card border-0 shadow-lg h-100" style="background: #062c21; border-radius: 15px; overflow: hidden;">
            <div style="height: 5px; background: linear-gradient(90deg, #00b894, #55efc4);"></div>
            <div class="card-body p-4">
                       
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h6 class="mb-0 fw-bold" style="color: #55efc4; letter-spacing: 2px; font-size: 0.8rem;">
                        <i class="fa-solid fa-gem me-2"></i>LUXURY ROOMS

                    </h6>
                     <span class="badge" style="background: rgba(212, 175, 55, 0.1); color: #00b894;">Gold</span>
                </div>
                <h5 class="fw-bold vip-total text-light">Total {{ $stats['luxury']['total'] }}</h5>
                
                <div class="row align-items-center rounded-4 p-3" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);">
                    <div class="col-4 text-center">
                        <p class="mb-1 text-uppercase text-white-50" style="font-size: 0.6rem; letter-spacing: 1px;">Avaliable</p>
                        <h3 class="fw-bold mb-0 text-white">{{ $stats['luxury']['available'] }}</h3>
                    </div>
                    <div class="col-4 text-center border-start border-end border-white border-opacity-10">
                        <p class="mb-1 text-uppercase text-white-50" style="font-size: 0.6rem; letter-spacing: 1px;">Booked</p>
                        <h3 class="fw-bold mb-0" style="color: #ff7675;">{{ $stats['luxury']['booked'] }}</h3>
                    </div>
                    <div class="col-4 text-center">
                        <p class="mb-1 text-uppercase text-white-50" style="font-size: 0.6rem; letter-spacing: 1px;">Maint.</p>
                        <h3 class="fw-bold mb-0 text-white-50">{{ $stats['luxury']['maintenance'] }}</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-0 shadow-lg h-100" style="background: linear-gradient(145deg, #334155 0%, #475569 100%);">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="mb-0 fw-bold text-white" style="letter-spacing: 1px;">
                        <i class="fa-solid fa-door-closed me-2"></i>NORMAL ROOMS
                    </h5>
                    <span class="badge bg-dark bg-opacity-25 text-white-50">Standard</span>
                </div>
                 <h5 class="fw-bold vip-total text-light">Total {{ $stats['normal']['total'] }}</h5>
                
                <div class="row g-0 rounded-3 p-3" style="background: rgba(0,0,0,0.1); border: 1px solid rgba(255,255,255,0.05);">
                    <div class="col-4 text-center">
                        <small class="text-uppercase fw-semibold text-white-50" style="font-size: 0.65rem;">Available</small>
                        <h3 class="fw-bold mb-0 mt-1 text-white">{{ $stats['normal']['available'] }}</h3>
                    </div>
                    <div class="col-4 text-center border-start border-white border-opacity-10 border-end">
                        <small class="text-uppercase fw-semibold text-white-50" style="font-size: 0.65rem;">Booked</small>
                        <h3 class="fw-bold mb-0 mt-1 text-white">{{ $stats['normal']['booked'] }}</h3>
                    </div>
                    <div class="col-4 text-center">
                        <small class="text-uppercase fw-semibold text-white-50" style="font-size: 0.65rem;">Maint.</small>
                        <h3 class="fw-bold mb-0 mt-1 text-white">{{ $stats['normal']['maintenance'] }}</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- filtering -->
<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body bg-light rounded">
        <form action="{{ route('rooms.index') }}" method="GET" class="row g-2 align-items-end">
            {{-- Filter by Class --}}
            <div class="col-md-3">
                <label class="form-label small fw-bold">Room Class</label>
                <select name="room_class" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Classes</option>
                    <option value="normal" {{ request('room_class') == 'normal' ? 'selected' : '' }}>Normal</option>
                    <option value="vip" {{ request('room_class') == 'vip' ? 'selected' : '' }}>VIP</option>
                    <option value="luxury" {{ request('room_class') == 'luxury' ? 'selected' : '' }}>Luxury</option>
                </select>
            </div>

            {{-- Filter by Type --}}
            <div class="col-md-3">
                <label class="form-label small fw-bold">Room Type</label>
                <select name="room_type" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Types</option>
                    <option value="single" {{ request('room_type') == 'single' ? 'selected' : '' }}>Single</option>
                    <option value="double" {{ request('room_type') == 'double' ? 'selected' : '' }}>Double</option>
                </select>
            </div>

            {{-- Filter by Status --}}
            <div class="col-md-3">
                <label class="form-label small fw-bold">Status</label>
                <select name="room_status" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Status</option>
                    <option value="available" {{ request('room_status') == 'available' ? 'selected' : '' }}>Available</option>
                    <option value="booked" {{ request('room_status') == 'booked' ? 'selected' : '' }}>Booked</option>
                    <option value="maintenance" {{ request('room_status') == 'maintenance' ? 'selected' : '' }}>Maintenance</option>
                </select>
            </div>

            {{-- Reset Button --}}
            <div class="col-md-3">
                <a href="{{ route('rooms.index') }}" class="btn btn-sm btn-outline-secondary w-100">
                    <i class="fa-solid fa-rotate-left"></i> Reset Filters
                </a>
            </div>
        </form>
    </div>
</div>
<!-- filtering -->

    <div class="mb-3 text-end">
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createRoomModal"><i class="fa-solid fa-plus text-white"></i> Add Room </button>
    </div>

    <table class="table table-bordered table-hover align-middle" id="rooms">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Room</th>
                <th>Type</th>
                <th>Class</th>
                <th>Status</th>
                <th>Size</th>
                <th>Price</th>
                <th>Photos</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        @forelse($rooms as $room)
            <tr>
                <td>{{ $loop->iteration + ($rooms->currentPage() - 1) * $rooms->perPage() }}</td>
                <td>{{ $room->room_number }}</td>
                <td>{{ ucfirst($room->room_type) }}</td>
                <td>{{ ucfirst($room->room_class) }}</td>
                <td>
                    <span class="badge bg-{{ $room->room_status === 'available' ? 'success' : ($room->room_status === 'booked' ? 'danger' : 'warning') }}">
                        {{ ucfirst($room->room_status) }}
                    </span>
                </td>
                <td>{{$room->room_size }} M<sup>2</sup></td>
                <td>{{ number_format($room->room_price, 2) }} ETB</td>
                <td>
                    @if($room->room_photos)
                        <div class="d-flex flex-wrap gap-1">
                            @foreach($room->room_photos as $photo)
                                <img src="{{ asset('storage/' . $photo) }}"
                                     alt="room photo"
                                     class="img-thumbnail room-thumb"
                                     style="width:50px;height:50px;object-fit:cover;cursor:pointer;"
                                     onclick="openModal('{{ asset('storage/' . $photo) }}')">
                            @endforeach
                        </div>
                    @else
                        <span class="text-muted">No photos</span>
                    @endif
                </td>

                  
              <td class="text-end pe-4 notexport">
    <div class="dropdown">
        <button
            class="btn btn-light btn-sm border px-3"
            type="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
        > 
            <i class="fa-solid fa-circle text-info" style="font-size:7px;"></i>
            <i class="fa-solid fa-circle text-success mx-1" style="font-size:7px;"></i>
            <i class="fa-solid fa-circle text-danger" style="font-size:7px;"></i>
        </button>

        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 p-1">

            @can('update-rooms')
                <li>
                    <a href="{{ route('rooms.edit', $room) }}"
                       class="dropdown-item d-flex align-items-center"
                       target="_blank">
                        <i class="fa-solid fa-pen-to-square me-2 text-primary"></i>
                        Edit Room
                    </a>
                </li>
            @endcan

            @can('delete-rooms')
                <li><hr class="dropdown-divider my-1"></li>
                <li>
                    <button
                        type="button"
                        class="dropdown-item d-flex align-items-center text-danger btn-delete-room"
                        data-url="{{ route('rooms.destroy', $room) }}"
                    >
                        <i class="fa-solid fa-trash-can me-2"></i>
                        Delete Room
                    </button>
                </li>
            @endcan

        </ul>
    </div>
</td>


            </tr>
        @empty
            <tr>
                <td colspan="8" class="text-center">No rooms found.</td>
            </tr>
        @endforelse
        </tbody>
    </table>

    <div class="mt-3">
        {{ $rooms->links() }}
    </div>
</div>

<!-- Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body p-0 text-center">
                <img id="modalImage" src="" class="img-fluid rounded shadow-sm">
            </div>
            <div class="text-center mt-2">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



<!-- Create Room Modal -->
<div class="modal fade" id="createRoomModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Create New Room</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="createRoomForm" action="{{ route('rooms.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">


                    <div class="row">
                         {{-- Room Number --}}
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Room Number</label>
                            <input type="text" name="room_number" class="form-control" required>
                        </div>

                        {{-- Room Type --}}
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Room Type</label>
                            <select name="room_type" class="form-select" required>
                                <option value="">-- Select --</option>
                                <option value="single">Single</option>
                                <option value="double">Double</option>
                            </select>
                        </div>

                        {{-- Room Class --}}
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Room Class</label>
                            <select name="room_class" class="form-select" required>
                                <option value="">-- Select --</option>
                                <option value="normal">NORMAL</option>
                                <option value="vip">VIP</option>
                                <option value="luxury">LUXURY</option>
                            </select>
                        </div>

                        {{-- Room Status --}}
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Room Status</label>
                            <select name="room_status" class="form-select">
                                <option value="available">Available</option>
                                <option value="booked">Booked</option>
                                <option value="maintenance">Maintenance</option>
                            </select>
                        </div>
                    </div>

                    {{-- Price --}}
                    <div class="row">
                        {{-- Price --}}
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Price (ETB)</label>
                            <input type="number" step="0.01" name="room_price" class="form-control" required>
                        </div>

                        {{-- Room Size --}}
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Room Size M<sup>2</sup></label>
                            <input type="number" step="0.1" name="room_size" class="form-control" placeholder="e.g. 35" required>
                        </div>
                    </div>


                    {{-- Services --}}
                    <div class="mb-3">
                        <label class="form-label">Room Services</label>
                        <div class="row">
                            @foreach(['wifi','tv','minibar','ac','balcony'] as $service)
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                               name="room_services[]" value="{{ $service }}">
                                        <label class="form-check-label">
                                            {{ strtoupper($service) }}
                                        </label>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                    {{-- Cleaned --}}
                    <div class="mb-3 form-check">
                        <input type="checkbox" name="room_is_cleaned" value="1" class="form-check-input" checked>
                        <label class="form-check-label">Room is Cleaned</label>
                    </div>

                    {{-- Photos --}}
                    <div class="mb-3">
                        <label class="form-label">Room Photos</label>
                        <input type="file" name="room_photos[]" class="form-control" multiple
                               onchange="previewImages(this)">
                    </div>

                    {{-- Preview --}}
                
                    <div class="mt-4">
                        <h6 class="fw-semibold mb-2">Image Preview</h6>
                        <div class="row g-2 border rounded p-2 bg-light" id="imagePreview"
                             style="min-height: 100px;">
                            <span class="text-muted small" id="previewHint">
                                Selected images will appear here
                            </span>
                        </div>
                    </div>


                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-success">
                        Save Room
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>


<script>
    $(document).ready(function(){
      
      var table=new DataTable('#rooms',{
          
          lengthMenu:[
            [5,10,25,50,100,500,'All'],
            [5,10,25,50,100,500,-1]
            ],

      });

    })
</script>

<script>
function openModal(src) {
    const modalImage = document.getElementById('modalImage');
    modalImage.src = src;
    const modal = new bootstrap.Modal(document.getElementById('imageModal'));
    modal.show();
}
</script>
<script>
function previewImages(input) {
    const preview = document.getElementById('imagePreview');
    const hint = document.getElementById('previewHint');
    preview.innerHTML = '';
    hint && hint.remove();

    Array.from(input.files).forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = e => {
            const col = document.createElement('div');
            col.className = 'col-6 col-md-3 position-relative';
            col.innerHTML = `
                <div class="card shadow-sm">
                    <img src="${e.target.result}"
                         class="img-fluid rounded"
                         style="height:100px;object-fit:cover;">
                    <button type="button"
                            class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1"
                            onclick="removePreview(${index}, this)">
                        &times;
                    </button>
                </div>`;
            preview.appendChild(col);
        };
        reader.readAsDataURL(file);
    });
}

function removePreview(index, btn) {
    const input = document.querySelector('input[name="room_photos[]"]');
    let files = Array.from(input.files);
    files.splice(index, 1);

    const dataTransfer = new DataTransfer();
    files.forEach(file => dataTransfer.items.add(file));
    input.files = dataTransfer.files;

    btn.closest('.col-6').remove();
}
</script>



<script>
document.getElementById('createRoomForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const form = this;
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerText = 'Saving...';
    }

    fetch(form.action, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: formData
    })
    .then(res => res.json())
    .then(data => {

        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = 'Save Room';
        }

        if (data.success) {
            bootstrap.Modal.getInstance(
                document.getElementById('createRoomModal')
            ).hide();

            form.reset();
            document.getElementById('imagePreview').innerHTML = `
                <span class="text-muted small">Selected images will appear here</span>
            `;

            window.location.reload();
        } else {
            alert(data.message || 'Something went wrong');
        }
    })
    .catch(() => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = 'Save Room';
        }
        alert('Server error occurred');
    });
});

</script>


<script>
document.addEventListener('click', function (e) {
    if (!e.target.classList.contains('btn-delete-room')) return;

    const button = e.target;
    const url = button.dataset.url;

    Swal.fire({
        title: 'Are you sure?',
        text: 'This room will be permanently deleted!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (!result.isConfirmed) return;

        button.disabled = true;
        button.innerText = 'Deleting...';

        fetch(url, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Deleted!',
                    text: data.message,
                    timer: 1500,
                    showConfirmButton: false
                });

                // remove row smoothly
                const row = button.closest('tr');
                row.style.transition = 'opacity 0.4s';
                row.style.opacity = 0;
                setTimeout(() => row.remove(), 400);
            } else {
                throw new Error(data.message);
            }
        })
        .catch(() => {
            Swal.fire('Error', 'Failed to delete room', 'error');
            button.disabled = false;
            button.innerText = 'Delete';
        });
    });
});
</script>

@endsection

