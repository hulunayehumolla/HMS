@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Add New Food</h5>
                </div>

                <div class="card-body">
                    <form action="{{ route('foods.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Food Name</label>
                                <input type="text" name="food_name" class="form-control" value="{{ old('food_name') }}" placeholder="Enter food name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Food Type</label>
                                <select name="food_type" class="form-select">
                                    <option value="">-- Select Type --</option>
                                    <option value="fasting">Fasting</option>
                                    <option value="non_fasting">Non-Fasting</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Category</label>
                                <input type="text" name="food_category" class="form-control" placeholder="e.g. Lunch, Dinner">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Number of Persons</label>
                                <input type="number" name="food_number_of_person" class="form-control" min="1">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Price (ETB)</label>
                                <input type="number" step="0.01" name="food_price" class="form-control" placeholder="0.00">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Food Photo</label>
                                <input type="file" name="food_photo" class="form-control">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="food_description" class="form-control" rows="3" placeholder="Write short description..."></textarea>
                        </div>

                        <div class="d-flex justify-content-end">
                            <a href="{{ route('foods.index') }}" class="btn btn-secondary me-2">Cancel</a>
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-plus-circle"></i> Add Food
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
