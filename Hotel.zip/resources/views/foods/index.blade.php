@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>Food Menu</h4>
        <a href="{{ route('foods.create') }}" class="btn btn-primary">
            Add Food
        </a>
    </div>

    <div class="row g-4">
        @foreach($foods as $food)
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">

                {{-- Food Image --}}
                @if($food->food_photo)
                    <img src="{{ asset('storage/'.$food->food_photo) }}"
                         class="card-img-top img-fluid"
                         style="max-height:200px; object-fit:cover;">
                @else
                    <div class="d-flex justify-content-center align-items-center bg-light"
                         style="height:200px;">
                        <span class="text-muted">No Image</span>
                    </div>
                @endif

                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ $food->food_name }}</h5>

                    <p class="card-text text-muted">
                        Type: {{ ucfirst(str_replace('_',' ', $food->food_type)) }}
                    </p>

                    <p class="card-text fw-bold">
                        Price: {{ number_format($food->food_price, 2) }} ETB
                    </p>

                    <div class="mt-auto d-flex justify-content-between">
                        <a href="{{ route('foods.edit', $food) }}"
                           class="btn btn-sm btn-warning">
                            ✏️ Edit
                        </a>
                        <form action="{{ route('foods.destroy', $food->food_name) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete {{ $food->food_name }}?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        </form>
<!-- 
                        <form action="{{ route('foods.destroy', $food) }}"
                              method="POST"
                              onsubmit="return confirm('Are you sure you want to delete this food?');">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-danger">🗑 Delete</button>
                        </form> -->
                    </div>
                </div>

            </div>
        </div>
        @endforeach
    </div>

    <div class="d-flex justify-content-center mt-4">
        {{ $foods->links() }}
    </div>
</div>
@endsection
