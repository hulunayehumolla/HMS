@extends('layouts.app')

@section('content')
<style>
    .is-invalid { border-color: #e3342f !important; }
    .is-invalid:focus { box-shadow: 0 0 0 0.2rem rgba(227, 52, 47, 0.25) !important; }

    .table tbody tr { transition: all 0.5s ease; }

    @keyframes highlight { from { background-color: #d4edda; } to { background-color: transparent; } }
    .highlight { animation: highlight 2s ease; }

    /* Dashboard Cards */
    .card-stat {
        border-radius: 15px;
        padding: 20px;
        color: #fff;
        position: relative;
        overflow: hidden;
    }
    .card-stat h3 { font-size: 1.5rem; margin-bottom: 0.5rem; }
    .card-stat p { font-size: 0.85rem; opacity: 0.8; }
</style>

<div class="container-fluid">

    <!-- Dashboard Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card-stat" style="background: linear-gradient(135deg, #1abc9c, #16a085);">
                <h3>{{ $stats['total'] ?? 0 }}</h3>
                <p>Total Guests</p>
                <i class="fa fa-users fa-2x" style="position:absolute;top:20px;right:20px;opacity:0.3;"></i>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-stat" style="background: linear-gradient(135deg, #3498db, #2980b9);">
                <h3>{{ $stats['male'] ?? 0 }}</h3>
                <p>Male Guests</p>
                <i class="fa fa-mars fa-2x" style="position:absolute;top:20px;right:20px;opacity:0.3;"></i>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-stat" style="background: linear-gradient(135deg, #e74c3c, #c0392b);">
                <h3>{{ $stats['female'] ?? 0 }}</h3>
                <p>Female Guests</p>
                <i class="fa fa-venus fa-2x" style="position:absolute;top:20px;right:20px;opacity:0.3;"></i>
            </div>
        </div>
    </div>

    <!-- Filters & Add Button -->
   <div class="row mb-3 align-items-center">
        <div class="col-md-10">
            <form id="filterForm" class="row g-2">
                <div class="col-md-4">
                    <input type="text" name="search" id="search" class="form-control form-control-sm" placeholder="Search Name, Phone, ID" value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select name="guest_sex" id="guest_sex" class="form-select form-select-sm">
                        <option value="">All Sex</option>
                        <option value="Male" {{ request('guest_sex')=='Male' ? 'selected' : '' }}>Male</option>
                        <option value="Female" {{ request('guest_sex')=='Female' ? 'selected' : '' }}>Female</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="guest_country" id="guest_country" class="form-control form-control-sm" placeholder="Country" value="{{ request('guest_country') }}">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="button" id="resetFilters" class="btn btn-sm btn-outline-secondary w-100"><i class="fa fa-refresh"></i> Reset</button>
                </div>
            </form>
        </div>
        <div class="col-md-2 text-end">
            <button class="btn btn-primary btn-sm" id="addGuest"><i class="fa fa-plus"></i> New Guest</button>
        </div>
    </div>


    <!-- Guest Table -->
    <div class="card shadow-sm">
        <div class="card-body table-responsive">
            <table class="table table-hover align-middle" id="guestTable">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Full Name</th>
                        <th>Phone</th>
                        <th>ID Info</th>
                        <th>Location</th>
                        <th>Sex</th>
                        <th width="150" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($guests as $index => $guest)
                        <tr id="row-{{ $guest->id }}">
                            <td>{{ $loop->iteration + ($guests->currentPage() - 1) * $guests->perPage() }}</td>
                            <td><strong>{{ $guest->guest_fname }} {{ $guest->guest_mname }} {{ $guest->guest_lname }}</strong></td>
                            <td>{{ $guest->guest_phone }}</td>
                            <td><span class="badge bg-primary">{{ $guest->guest_id_type }}</span> <br> <small>{{ $guest->guest_id_number }}</small></td>
                            <td>{{ $guest->guest_town }}, {{ $guest->guest_country }}</td>
                            <td>{{ $guest->guest_sex }}</td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-outline-info edit" data-id="{{ $guest->id }}"><i class="fa fa-edit"></i></button>
                                <button class="btn btn-sm btn-outline-danger delete" data-id="{{ $guest->id }}"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="text-center">No guests found.</td></tr>
                    @endforelse
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="mt-3">
                {{ $guests->links() }}
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="guestModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg border-0">
        <form id="guestForm">
            @csrf
            <input type="hidden" id="method_field" name="_method" value="POST">
            <input type="hidden" id="guest_id" name="id">

            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h5 class="modal-title" id="modalTitle">Guest Registration</h5>
                    <button type="button" class="Close btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">ID Type <span class="text-danger">*</span></label>
                            <select name="guest_id_type" class="form-control" required>
                                <option value="">Select ID Type</option>
                                <option value="National ID">National ID</option>
                                <option value="Driver License">Driver License</option>
                                <option value="Kebele ID">Kebele ID</option>
                                <option value="Employment ID">Employment ID</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">ID Number <span class="text-danger">*</span></label>
                            <input name="guest_id_number" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Sex <span class="text-danger">*</span></label>
                            <select name="guest_sex" class="form-control" required>
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">First Name <span class="text-danger">*</span></label>
                            <input name="guest_fname" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Middle Name</label>
                            <input name="guest_mname" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Last Name <span class="text-danger">*</span></label>
                            <input name="guest_lname" class="form-control" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Phone <span class="text-danger">*</span></label>
                            <input name="guest_phone" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="guest_email" class="form-control">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Country <span class="text-danger">*</span></label>
                            <input name="guest_country" class="form-control" value="Ethiopia" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Region</label>
                            <input name="guest_region" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Town</label>
                            <input name="guest_town" class="form-control">
                        </div>

                        <div class="col-md-12">
                            <label class="form-label">Registered By <span class="text-danger">*</span></label>
                            <input name="guest_reg_by" class="form-control" value="{{Auth::user()->first_name ?? '' }} {{Auth::user()->middle_name ?? '' }}" readonly>
                        </div>
                    </div>
                </div>

                <div class="modal-footer bg-light">
                    <button type="button" class="btn Close btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                    <button type="submit" id="saveBtn" class="btn btn-success btn-sm">Save Guest</button>
                </div>
            </div>
        </form>
    </div>
</div>



<script>
$(document).ready(function() {

    // --- Filter on Change ---
    $('#search, #guest_sex, #guest_country').on('change keyup', function() {
        let params = {
            search: $('#search').val(),
            guest_sex: $('#guest_sex').val(),
            guest_country: $('#guest_country').val()
        };
        let query = $.param(params);
        window.location.href = "{{ route('guests.index') }}?" + query;
    });

    // --- Reset Filters ---
    $('#resetFilters').click(function() {
        $('#search').val('');
        $('#guest_sex').val('');
        $('#guest_country').val('');
        window.location.href = "{{ route('guests.index') }}";
    });

    // --- Add Guest Modal ---
    $('#addGuest').click(function () {
        $('#guestForm')[0].reset();
        $('#guest_id').val('');
        $('#modalTitle').text('New Guest Registration');
        $('.form-control').removeClass('is-invalid');
        $('#guestModal').modal('show');
    });

    $('.Close').click(function () {
        $('#guestForm')[0].reset();
        $('#guest_id').val('');
        $('#modalTitle').text('New Guest Registration');
        $('.form-control').removeClass('is-invalid');
        $('#guestModal').modal('hide');
    });

    // --- Store/Update Guest ---
    $('#guestForm').submit(function (e) {
        e.preventDefault();
        let id = $('#guest_id').val();
        let url = id ? `{{ route('guests.update', ':id') }}`.replace(':id', id) : `{{ route('guests.store') }}`;
        let submitBtn = $('#saveBtn');

        submitBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Processing...');

        $.ajax({
            url: url,
            type: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                $('#guestModal').modal('hide');
                Swal.fire({ icon: 'success', title: 'Success!', text: response.message, timer: 1500, showConfirmButton: false })
                .then(() => { location.reload(); });
            },
            error: function (xhr) {
                submitBtn.prop('disabled', false).text('Save Guest');
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $('.form-control').removeClass('is-invalid');
                    $.each(errors, function (key) { $(`[name="${key}"]`).addClass('is-invalid'); });
                } else {
                    Swal.fire('Error', 'Something went wrong on the server.', 'error');
                }
            }
        });
    });

    // --- Edit Guest ---
    $(document).on('click', '.edit', function () {
        let id = $(this).data('id');
        let url = `{{ route('guests.edit', ':id') }}`.replace(':id', id);
        $('.form-control').removeClass('is-invalid');

        $.get(url, function (data) {
            $('#guest_id').val(data.id);
            $('#modalTitle').text('Update Guest: ' + data.guest_fname);
            Object.keys(data).forEach(key => { let $el = $(`[name="${key}"]`); if($el.length) $el.val(data[key]); });
            $('#guestModal').modal('show');
        });
    });

    // --- Delete Guest ---
    $(document).on('click', '.delete', function () {
        let id = $(this).data('id');
        let url = `{{ route('guests.destroy', ':id') }}`.replace(':id', id);
        let row = $(`#row-${id}`);

        Swal.fire({
            title: 'Are you sure?',
            text: "This guest record will be permanently deleted!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
            preConfirm: () => $.ajax({ url: url, type: 'DELETE' })
        }).then((result) => {
            if (result.isConfirmed) {
                row.addClass('table-danger').fadeOut(800, function() { $(this).remove(); });
                Swal.fire('Deleted!', 'Guest has been removed.', 'success');
            }
        });
    });

});

</script>




@endsection
