<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Employee;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class DefaultUserSeeder extends Seeder
{
    public function run(): void
    {
        // Roles
        $superAdminRole = Role::firstOrCreate(['name' => 'Super Admin']);
        $adminRole      = Role::firstOrCreate(['name' => 'Admin']);

        // Users data (ADD MORE USERS HERE)
        $users = [
            [
                'role' => 'Admin',
                'employee' => [
                    'emp_Id' => 'inu1224',
                    'emp_Fname' => 'Ahmed',
                    'emp_Mname' => 'Mohamed',
                    'emp_Lname' => 'Kemal',
                    'emp_coll_dirId' => 'cet',
                    'emp_dept_teamId' => 'cs',
                    'emp_Status' => 'Active',
                ],
                'user' => [
                    'email' => 'ahmedpg08@gmail.com',
                    'username' => 'inu1224',
                ],
            ],
            [
                'role' => 'Super Admin',
                'employee' => [
                    'emp_Id' => 'inu1373',
                    'emp_Fname' => 'Andualem',
                    'emp_Mname' => 'Muche',
                    'emp_Lname' => 'Gobezie',
                    'emp_coll_dirId' => 'cet',
                    'emp_dept_teamId' => 'cs',
                    'emp_Status' => 'Active',
                ],
                'user' => [
                    'email' => 'andualem1164@gmail.com',
                    'username' => 'inu1373',
                ],
            ],

            // 🔹 NEW USER 3
            [
                'role' => 'Admin',
                'employee' => [
                    'emp_Id' => 'inu506',
                    'emp_Fname' => 'Aberham',
                    'emp_Mname' => 'Sewnet',
                    'emp_Lname' => 'Kassa',
                    'emp_coll_dirId' => 'cet',
                    'emp_dept_teamId' => 'cs',
                    'emp_Status' => 'Active',
                ],
                'user' => [
                    'email' => 'seab22245@gmail.com',
                    'username' => 'inu506',
                ],
            ],

            // 🔹 NEW USER 4
            [
                'role' => 'Admin',
                'employee' => [
                    'emp_Id' => 'inu416',
                    'emp_Fname' => 'Hulunayehu',
                    'emp_Mname' => 'Molla',
                    'emp_Lname' => 'Yisak',
                    'emp_coll_dirId' => 'cet',
                    'emp_dept_teamId' => 'cs',
                    'emp_Status' => 'Active',
                ],
                'user' => [
                    'email' => 'kulumolla21@gmail.com',
                    'username' => 'inu416',
                ],
            ],
        ];

        foreach ($users as $data) {

            // Employee
            $employee = Employee::firstOrCreate(
                ['emp_Id' => $data['employee']['emp_Id']],
                $data['employee']
            );

            // User
            $user = User::firstOrCreate(
                ['email' => $data['user']['email']],
                [
                    'username' => $data['user']['username'],
                    'password' => Hash::make(strtolower($data['user']['username']) . '123#'),
                    'status' => '1',
                    'profileable_type' => Employee::class,
                    'profileable_id' => $employee->id,
                ]
            );

            // Assign Role
            $user->syncRoles([$data['role']]);
        }

        // Super Admin Permissions
        $superAdmin = User::where('email', 'andualem1164@gmail.com')->first();

        if ($superAdmin) {
            $superAdmin->givePermissionTo([
                'create-role',
                'edit-role',
                'delete-role',
                'create-user',
                'edit-user',
                'edit-user-status',
                'edit-user-role',
                'delete-user',
            ]);
        }
    }
}
