<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Http\Requests\RoomRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

class RoomController extends Controller
{
   public function index(Request $request)
{
    // 1. Filtering
    $query = Room::query();

    if ($request->filled('room_class')) {
        $query->where('room_class', $request->room_class);
    }

    if ($request->filled('room_type')) {
        $query->where('room_type', $request->room_type);
    }

    if ($request->filled('room_status')) {
        $query->where('room_status', $request->room_status);
    }

    // Paginate results
    $rooms = $query->latest()->paginate(10)->withQueryString();

    // 2. Stats for dashboard cards
    $stats = Room::select(
            'room_class',
            DB::raw('COUNT(*) as total'),
            DB::raw("SUM(CASE WHEN room_status = 'available' THEN 1 ELSE 0 END) as available"),
            DB::raw("SUM(CASE WHEN room_status = 'booked' THEN 1 ELSE 0 END) as booked"),
            DB::raw("SUM(CASE WHEN room_status = 'maintenance' THEN 1 ELSE 0 END) as maintenance")
        )
        ->groupBy('room_class')
        ->get()
        ->keyBy('room_class')
        ->map(function($item){
            return [
                'total' => $item->total,
                'available' => $item->available,
                'booked' => $item->booked,
                'maintenance' => $item->maintenance,
            ];
        })
        ->toArray();

    // Ensure all classes exist even if 0
    $roomClasses = ['vip', 'luxury', 'normal'];
    foreach ($roomClasses as $class) {
        if (!isset($stats[$class])) {
            $stats[$class] = [
                'total' => 0,
                'available' => 0,
                'booked' => 0,
                'maintenance' => 0,
            ];
        }
    }

    return view('rooms.index', compact('rooms', 'stats'));
}


    public function create()
    {
        return view('rooms.create');
    }

    public function store(RoomRequest $request){
    try {
        $room = DB::transaction(function () use ($request) {
            $photos = [];

            if ($request->hasFile('room_photos')) {
                foreach ($request->file('room_photos') as $photo) {
                    $photos[] = $photo->store('rooms', 'public');
                }
            }

            return Room::create([
                ...$request->validated(),
                'room_photos' => $photos,
            ]);
        });

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Room created successfully',
                'room'    => $room
            ]);
        }

        return redirect()->route('rooms.index')->with('success', 'Room created successfully');

    } catch (\Throwable $e) {

        if ($request->ajax()) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create room'
            ], 500);
        }

        return back()->withErrors(['error' => 'Failed to create room']);
    }
}


    public function edit(Room $room)
    {
        return view('rooms.edit', compact('room'));
    }

    public function update(RoomRequest $request, Room $room)
    {
        try {
            DB::transaction(function() use ($request, $room){
                $photos = $room->room_photos ?? [];

                // Add new uploaded photos
                if ($request->hasFile('room_photos')) {
                    foreach ($request->file('room_photos') as $photo) {
                        $photos[] = $photo->store('rooms', 'public');
                    }
                }

                $room->update([
                    ...$request->validated(),
                    'room_photos' => $photos,
                ]);
            });

            if ($request->ajax()) {
                return response()->json(['success' => 'Room updated successfully']);
            }

            return redirect()->route('rooms.index')->with('success', 'Room updated successfully');

        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json(['error' => 'Failed to update room'], 500);
            }
            return back()->withErrors(['error' => 'Failed to update room']);
        }
    }

  public function destroy(Room $room)
{
    try {
        // delete images if needed
        if ($room->room_photos) {
            foreach ($room->room_photos as $photo) {
                \Storage::disk('public')->delete($photo);
            }
        }

        $room->delete();

        return response()->json([
            'success' => true,
            'message' => 'Room deleted successfully'
        ]);

    } catch (\Throwable $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to delete room'
        ], 500);
    }
}


    public function deletePhoto(Room $room, $index)
    {
        $photos = $room->room_photos ?? [];
        if (isset($photos[$index])) {
            $photo = $photos[$index];
            if (Storage::disk('public')->exists($photo)) {
                Storage::disk('public')->delete($photo);
            }

            array_splice($photos, $index, 1);
            $room->update(['room_photos' => $photos]);

            return response()->json(['success' => 'Photo removed successfully']);
        }

        return response()->json(['error' => 'Photo not found'], 404);
    }
}
