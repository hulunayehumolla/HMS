<?php

namespace App\Http\Controllers;

use App\Models\FoodMenu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FoodMenuController extends Controller
{
    public function index()
    {
        $foods = FoodMenu::latest()->paginate(10);
        return view('foods.index', compact('foods'));
    }

 

    public function create()
    {
        return view('foods.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'food_name' => 'required|string|max:255',
            'food_type' => 'required|in:fasting,non_fasting',
            'food_category' => 'required|string|max:255',
            'food_content' => 'nullable|string',
            'food_number_of_person' => 'required|integer|min:1',
            'food_description' => 'nullable|string',
            'food_price' => 'required|numeric|min:0',
            'food_photo' => 'nullable|image|max:2048',
        ]);

        // Upload image to storage/app/public/foods
        $data['food_content']=$request->food_description;
        
        if ($request->hasFile('food_photo')) {
            $data['food_photo'] = $request
                ->file('food_photo')
                ->store('foods', 'public');
        }

        FoodMenu::create($data);

        return redirect()->route('foods.index')
            ->with('success', 'Food added successfully');
    }

    public function edit(FoodMenu $food)
    {
        return view('foods.edit', compact('food'));
    }

    public function update(Request $request, FoodMenu $food)
    {
        $data = $request->validate([
            'food_name' => 'required|string|max:255',
            'food_type' => 'required|in:fasting,non_fasting',
            'food_category' => 'required|string|max:255',
            'food_content' => 'nullable|string',
            'food_number_of_person' => 'required|integer|min:1',
            'food_description' => 'nullable|string',
            'food_price' => 'required|numeric|min:0',
            'food_photo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('food_photo')) {

            // delete old photo
            if ($food->food_photo) {
                Storage::disk('public')->delete($food->food_photo);
            }

            $data['food_photo'] = $request
                ->file('food_photo')
                ->store('food', 'public');
        }

        $food->update($data);

        return redirect()->route('foods.index')
            ->with('success', 'Food updated successfully');
    }

   public function destroy($name)
{
    // 1. Find the food by name (using firstOrFail to handle 404 if not found)
    $food = FoodMenu::where('food_name', $name)->firstOrFail();

    // 2. Delete the photo from storage if it exists
    if ($food->food_photo) {
        Storage::disk('public')->delete($food->food_photo);
    }

    // 3. Delete the record
    $food->delete();

    return redirect()->route('foods.index')
        ->with('success', "Food '{$name}' has been deleted.");
}
}
