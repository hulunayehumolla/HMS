<?php

namespace App\Http\Controllers;

use App\Models\Guest;
use App\Http\Requests\GuestRequest;
use Illuminate\Http\Request;

class GuestController extends Controller
{
    /**
     * Display a listing of the guests with optional search & filters.
     */
    public function index(Request $request)
    {
        $query = Guest::query();

        // Optional filtering by name, phone, or ID
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                 $q->where('guest_fname', 'like', "%{$search}%")
                  ->orWhere('guest_mname', 'like', "%{$search}%")
                  ->orWhere('guest_lname', 'like', "%{$search}%")
                  ->orWhere('guest_phone', 'like', "%{$search}%")
                  ->orWhere('guest_id_number', 'like', "%{$search}%");
            });
        }

        // Optional filtering by country, sex
        if ($request->filled('guest_sex')) {
            $query->where('guest_sex', $request->guest_sex);
        }

        if ($request->filled('guest_country')) {
            $query->where('guest_country', $request->guest_country);
        }

        // Pagination with filters
        $guests = $query->latest()->paginate(10)->withQueryString();

        return view('guests.index', compact('guests'));
    }

    /**
     * Store a newly created guest.
     */

   public function store(GuestRequest $request) {
    
    $data = $request->validated();

    // Automatically set registration date to now
    $data['guest_reg_date'] = now();

    // Set registered_by from logged-in user
    $user=auth()->user()->first_name?? 'System'. auth()->user()->middle_name ?? 'System';
    $data['guest_reg_by'] = $user ?? 'System';

    $guest = Guest::create($data);

    return response()->json([
        'success' => true,
        'message' => 'Guest registered successfully!',
        'data'    => $guest
    ]);
   }
   /**
     * Return guest info for AJAX edit.
     */


 public function edit(Guest $guest){
        return response()->json($guest);
    }

public function update(GuestRequest $request, Guest $guest)
{
    $data = $request->validated();
    // Ensure registration date is not changed
    $data['guest_reg_date'] = $guest->guest_reg_date;

    // Keep registered_by as is or allow update if needed
    $data['guest_reg_by'] = $guest->guest_reg_by;

    $guest->update($data);

    return response()->json([
        'success' => true,
        'message' => 'Guest updated successfully!',
        'data'    => $guest
    ]);
}


    /**
     * Delete guest record.
     */
    public function destroy(Guest $guest)
    {
        $guest->delete();

        return response()->json([
            'success' => true,
            'message' => 'Guest deleted successfully!'
        ]);
    }
}
