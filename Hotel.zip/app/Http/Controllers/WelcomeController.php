<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Room;
use App\Models\FoodMenu;

class WelcomeController extends Controller
{
     public function welcome()
    {
        // Rooms
        $roomsGrouped = Room::all()->groupBy('room_class');

        // Foods
        $foods = FoodMenu::latest()->get();

        return view('welcome', compact('roomsGrouped', 'foods'));
    }

    public function edit(FoodMenu $food)
    {
        return view('edit', compact('food'));
    }

    public function update(Request $request, FoodMenu $food)
    {
        $data = $request->validate([
            'food_name' => 'required|string|max:255',
            'food_type' => 'required|in:fasting,non_fasting',
            'food_category' => 'required|string|max:255',
            'food_content' => 'nullable|string',
            'food_number_of_person' => 'required|integer|min:1',
            'food_description' => 'nullable|string',
            'food_price' => 'required|numeric|min:0',
            'food_photo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('food_photo')) {

            // delete old photo
            if ($food->food_photo) {
                Storage::disk('public')->delete($food->food_photo);
            }

            $data['food_photo'] = $request
                ->file('food_photo')
                ->store('food', 'public');
        }

        $food->update($data);

        return redirect()->route('welcome')
            ->with('success', 'Food updated successfully');
    }
}
